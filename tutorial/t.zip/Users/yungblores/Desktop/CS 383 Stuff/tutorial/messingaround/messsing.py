orderList = [('apples', 2.0), ('pears', 3.0), ('limes', 4.0)]

for i in range(len(orderList)):
    print (orderList[i])

